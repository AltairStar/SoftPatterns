package sample;

public class Main
{
    public Main() {
    }

    public static void main(String[] args)
    {
        heroes Invoker = new InvokerHero();
        heroes juggernaut = new JuggernautHero();
        Invoker.display();
        Invoker.performAttack();
        Invoker.performComplexitys();
        juggernaut.display();
        juggernaut.performAttack();
        juggernaut.performComplexitys();
    }
}