package sample;

public class InvokerHero extends heroes {
    void display() {
        System.out.println("This hero's name is Invoker");
    }
    public InvokerHero() {
        super(new DistantAttack(),new SecondComplexity());
    }
}
