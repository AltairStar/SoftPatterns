package sample;

public class SecondComplexity implements Complexity {
    @Override
    public void complexitys() {
        System.out.println("This hero has second level of difficulty of usage");
    }
}
