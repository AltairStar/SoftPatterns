package sample;

public abstract class heroes {
    private AttackStrategy attackstrategy;
    private Complexity complexity;

    public heroes(AttackStrategy attackstrategy,Complexity complexity) {
        this.attackstrategy=attackstrategy;
        this.complexity=complexity;
    }

    abstract void display();

    public void performAttack() {
        this.attackstrategy.attack();
    }

    public void performComplexitys() {
        this.complexity.complexitys();
    }
//
//    public AttackStrategy getAttackStrategy()
//    {
//        return this.attackstrategy;
//    }
//    public AttackStrategy setAttackStrategy(AttackStrategy attackstrategy)
//    {
//        this.attackstrategy=attackstrategy;
//    }
//
//    public Complexity getComplexity()
//    {
//        return this.complexity;
//    }
//    public Complexity setComplexity(Complexity complexity)
//    {
//        this.complexity=complexity;
//    }

}
