package sample;

public class FirstComplexity implements Complexity {
    @Override
    public void complexitys() {
        System.out.println("This hero has first level of difficulty of usage");
    }
}
