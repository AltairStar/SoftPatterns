package sample;

public interface Complexity {
    void complexitys();
}
