package sample;

public class JuggernautHero extends heroes {
    void display() {
        System.out.println("This hero's name is Juggernaut");
    }
    public JuggernautHero() {
        super(new CloseAttack(),new FirstComplexity());
    }
}
