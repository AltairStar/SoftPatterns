package sample;

public class CloseAttack implements AttackStrategy {
    @Override
    public void attack() {
        System.out.println("This hero has close attack strategy");
    }
}
