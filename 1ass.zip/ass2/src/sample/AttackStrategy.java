package sample;

public interface AttackStrategy {
    void attack();
}
