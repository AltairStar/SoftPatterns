package sample;

public class DistantAttack implements AttackStrategy {
    @Override
    public void attack() {
        System.out.println("This hero has distant battle strategy");
    }
}
